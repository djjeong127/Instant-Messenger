#include <stdlib.h>
#include <string.h>

#include "serialize.h"

/* Pack the user input provided in input into the appropriate message
 * type in the space provided by packed.  You can assume that input is a
 * NUL-terminated string, and that packed is a buffer of size
 * PACKET_SIZE.
 *
 * Returns the message type for valid input, or -1 for invalid input.
 */
int pack(void *packed, char *input) {
    int messagetype = -1;
    char ubitName[NAME_SIZE] = "djjeong";
    
    int check;
    int space = 0;
    for (check = 0; input[check] != '\0'; check++) {
        if (input[check] == ' ') {
            space++;
        }
    }

    
    if (check == space || input == NULL) {
        messagetype = -1;
    }
    else if (input[0] == '/' && input[1] == 'm' && input [2] == 'e' && input[3] != ' ') {
        messagetype = -1;
    }
    
    //STATISTICS
    else if (input[0] == '/' && input[1] == 's' && input[2] == 't' && input[3] == 'a' && input[4] == 't' && input[5] == 's' && ((input[6] == ' ' && input[7] == '\0') ||input[6] == '\0')) {
        messagetype = STATISTICS;
        int i;
        
        *(int *)packed = messagetype;
        packed += sizeof(int);

        for (i = 0; i < sizeof(ubitName); i++) {
            *(char *)packed = ubitName[i];
            packed += sizeof(char);
        }
        
    }
    
    //LABELED
    else if (input[0] == '@' && input[1] != ' ') {
        int to = 1;
        while (input[to] != ' ') {
            to++;
        }
        to -= 1;
        if (to <= NAME_SIZE) {
            messagetype = LABELED;
            int i, mess, target;
            int messlen = 0;
            int targetlen = 0;
            int bool = 0;

            *(int *)packed = messagetype;
            packed += sizeof(int);

            for (i = 0; i < sizeof(ubitName); i++) {
                *(char *)packed = ubitName[i];
                packed += sizeof(char);
            }

            packed += 3 * sizeof(size_t);
            for (mess = to + 1; input[mess] != '\0'; mess++) {
                if (input[mess] != ' ') {
                    bool++;
                }
                if (bool > 0) {
                    *(char *)packed = input[mess];
                    packed += sizeof(char);
                    messlen++;
                }
            }
            for (target = 1; target <= to; target++) {
                *(char *)packed = input[target];
                packed += sizeof(char);
                targetlen++;
            }
            packed -= ((messlen + targetlen) * sizeof(char) + 3 * sizeof(size_t));
            *(size_t *)packed = messlen;
            packed += sizeof(size_t);
            *(size_t *)packed = targetlen;
            packed += sizeof(size_t);
            *(size_t *)packed = 0;
        }
    }

    //STATUS
    else if (input[0] == '/' && input[1] == 'm' && input [2] == 'e' && input[3] == ' ') {
        messagetype = STATUS;
        int i;
        int bool = 0;

        *(int *)packed = messagetype;
        packed += sizeof(int);

        for (i = 0; i < sizeof(ubitName); i++) {
            *(char *)packed = ubitName[i];
            packed += sizeof(char);
        }

        packed += 2 * sizeof(size_t);
        for (i = 3; input[i] != '\0'; i++) {
            if (input[i] != ' ') {
                bool++;
            }
            if (bool > 0) {
                *(char *)packed = input[i];
                packed += sizeof(char);
            }
        }
        packed -= (2 * sizeof(size_t) + (i - 4) * sizeof(char));
        *(size_t *)packed = i - 4;
        packed += sizeof(size_t);
        *(size_t *)packed = 0;
    }
    
    //MESSAGE
    else {
        messagetype = MESSAGE;
        int i;
        
        *(int *)packed = messagetype;
        packed += sizeof(int);
        
        for (i = 0; i < sizeof(ubitName); i++) {
            *(char *)packed = ubitName[i];
            packed += sizeof(char);
        }
        
        //jump to char[] place in void pointer
        packed += 2 * sizeof(size_t);
        for (i = 0; input[i] != '\0'; i++) {
            *(char *)packed = input[i];
            packed += sizeof(char);
        }
        packed -= ((2 * sizeof(size_t)) + (i * sizeof(char)));
        *(size_t *)packed = i;
        packed += sizeof(size_t);
        *(size_t *)packed = 0;
    }
    return messagetype;
}

/* Create a refresh packet for the given message ID.  You can assume
 * that packed is a buffer of size PACKET_SIZE.
 *
 * You should start by implementing this method!
 *
 * Returns the message type.
 */
int pack_refresh(void *packed, int message_id) {
    int messagetype = REFRESH;
    int i;
    char ubitName[NAME_SIZE] = "djjeong";
    *(int *)packed = messagetype;
    packed += sizeof(int);
    for (i = 0; i < sizeof(ubitName); i++) {
        *(char *)packed = ubitName[i];
        packed += sizeof(char);
    }
    *(int *)packed = message_id;
    return messagetype;
}
