#include <stdlib.h>
#include <string.h>

#include "serialize.h"

/* Unpack the given message into the buffer unpacked.  You can assume
 * that packed points to a message buffer large enough to hold the
 * message described therein, but you cannot assume that the message is
 * otherwise valid.  You can assume that unpacked points to a character
 * buffer large enough to store the unpacked message, if it is a valid
 * message.
 *
 * Returns the message type that was unpacked, or -1 if it is invalid.
 */
int unpack(char *unpacked, void *packed) {
    int messagetype = -1;
    int i, j;
    size_t messagelen;

    //LABELED
    if (*(int *)packed == LABELED) {
        messagetype = LABELED;
        size_t targetlen;
        packed += sizeof(int);
        for (i = 0; *(char *)packed != '\0'; i++) {
            unpacked[i] = *(char *)packed;
            packed += sizeof(char);
        }
        packed += (NAME_SIZE - i) * sizeof(char);
        messagelen = *(size_t *)packed;
        packed += sizeof(size_t);
        targetlen = *(size_t *)packed;
        packed += 2 * sizeof(size_t);

        unpacked[i] = ':';
        i++;
        unpacked[i] = ' ';
        i++;
        unpacked[i] = '@';
        i++;

        packed += messagelen * sizeof(char);
        for (j = 0; j < targetlen; j++) {
            unpacked[i] = *(char *)packed;
            i++;
            packed += sizeof(char);
        }
        packed -= (messagelen + targetlen) * sizeof(char);

        unpacked[i] = ' ';
        i++;

        for (j = 0; j < messagelen; j++) {
            unpacked[i] = *(char *)packed;
            i++;
            packed += sizeof(char);
        }
        unpacked[i] = '\0';
    }

    //STATUS
    else if (*(int *)packed == STATUS) {
        messagetype = STATUS;
        packed += sizeof(int);
        for (i = 0; *(char *)packed != '\0'; i++) {
            unpacked[i] = *(char *)packed;
            packed += sizeof(char);
        }
        packed += (NAME_SIZE - i) * sizeof(char);
        messagelen = *(size_t *)packed;
        packed += 2 * sizeof(size_t);
        
        unpacked[i] = ' ';
        i++;
        for (j = 0; j < messagelen; j++) {
            unpacked[i] = *(char *)packed;
            i++;
            packed += sizeof(char);
        }
        unpacked[i] = '\0';
    }
    //MESSAGE
    else if (*(int *)packed == MESSAGE) {
        messagetype = MESSAGE;
        packed += sizeof(int);
        for (i = 0; *(char *)packed != '\0'; i++) {
            unpacked[i] = *(char *)packed;
            packed += sizeof(char);
        }
        packed += (NAME_SIZE - i) * sizeof(char);
        messagelen = *(size_t *)packed;
        packed += 2 * sizeof(size_t);
        
        unpacked[i] = ':';
        i++;
        unpacked[i] = ' ';
        i++;
        for (j = 0; j < messagelen; j++) {
            unpacked[i] = *(char *)packed;
            i++;
            packed += sizeof(char);
        }
        unpacked[i] = '\0';
    }
    return messagetype;
}

/* Unpack the given packed message into the given statistics structure.
 * You can assume that packed points to a message buffer large enough to
 * hold the statistics message, but you cannot assume that it is
 * otherwise valid.  You can assume that statistics points to a
 * statistics structure.
 *
 * Returns the message type that was unpacked, or -1 if it is invalid.
 */
int unpack_statistics(struct statistics *statistics, void *packed) {
    int messagetype = -1;
    if (*(int *)packed == STATISTICS) {
        int i;
        messagetype = STATISTICS;
        packed += sizeof(int);

        for (i = 0; i < NAME_SIZE; i++) {
            statistics -> sender[i] = *(char *)packed;
            packed += sizeof(char);
        }
        for (i = 0; i < NAME_SIZE; i++) {
            statistics -> most_active[i] = *(char *)packed;
            packed += sizeof(char);
        }
        statistics ->most_active_count = *(int *)packed;
        packed += sizeof(int);
        statistics -> invalid_count = *(long *)packed;
        packed += sizeof(long);
        statistics -> refresh_count = *(long *)packed;
        packed += sizeof(long);
        statistics -> messages_count = *(int *)packed;
    }
    return messagetype;
}
